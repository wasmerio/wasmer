"""Rebuild portable arm64 bench tables and audit all Criterion slopes from the raw samples."""
import argparse,csv,hashlib,json,math,statistics
from collections import Counter,defaultdict
from pathlib import Path
from shutil import copyfile
from statistics import median
BASE="c2366fe3c70acc8d713540051efc0203c5ee8311"
IM="acb8542694cd3970d96e39088b8873dfe8cc627c"
SC="d3b2953ef5354ecc55a04e6f1ed58df3aba28798"
H="509ba1e0a25ea00e5f2ef5c676a0a45d635627d5"
GH="https://github.com/wasmerio/wasmer"
ENG=["pr","imports_only","scalar_result","wasmtime"]
def csvwrite(path,rows):
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def load(p): return json.loads(p.read_text())
def sh(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pct(x): return f"{(x-1)*100:+.1f}%"
CASES={"entry":[("typed","Typed"),("dynamic","Dynamic"),("typed_ready","Typed ready"),("dynamic_ready","Dynamic ready"),("typed_suspend","Typed suspended once"),("dynamic_suspend","Dynamic suspended once"),("import_only","Guest → host add, including outer call"),("nested_typed_1","Typed reentry, one level"),("nested_dynamic_1","Dynamic reentry, one level"),("nested_typed_2","Typed reentry, two levels"),("nested_dynamic_2","Dynamic reentry, two levels"),("native","Native Rust add control")],
"imports":[("guest_loop","Guest-only arithmetic"),("import_typed","Typed sync"),("import_dynamic","Dynamic sync"),("import_typed_ready","Typed ready"),("import_dynamic_ready","Dynamic ready"),("import_typed_suspend","Typed suspended once"),("import_dynamic_suspend","Dynamic suspended once")]}
def verify(raw,harness,suite):
    d=raw/suite; des=load(d/"design.json"); count=des["batch"]; assert count==(4096 if suite=="imports" else 1)
    assert des["rounds"]==8 and des["samples"]==24 and des["hardware"]["chip_type"]=="Apple M5 Max"
    assert set(des["cases"])=={case for case,_ in CASES[suite]}
    stamps=[]
    for v,rev in zip(ENG,[BASE,IM,SC]):
        build=load(d/f"build-{v}.json"); assert build["file"]=="Mach-O arm64" and build["llvm"]=="23.1.5"
        assert "aarch64-apple-darwin" in build["rust"] and build["revision"]==rev
        assert build["harness_sha256"]==sh(harness/(suite+".rs"))
        assert {"wasmer","wasmer_compiler_llvm","wasmer_vm"}<=set(load(raw/f"rebuilt-{v}.json"))
        stamps.append(build["executable_sha256"])
        if suite=="imports":
            for n in ("loop.wasm","import.wasm"):
                assert sh(d/f"modules-{v}"/n)==sh(harness/"v8/imports"/n)
    assert len(set(stamps))==3
    ag=load(d/"summary.json"); sch=[json.loads(l) for l in (d/"schedule.jsonl").read_text().splitlines()]
    rows=[];statrows=[]; seen=set();orders=defaultdict(list); ns=defaultdict(lambda:defaultdict(list))
    for row in sch:
        k=row["case"];v=row["run"];i=row["block"];assert (i,k,v) not in seen;seen.add((i,k,v))
        fs=list((d/f"round-{i:02d}"/k/v).glob("**/new/estimates.json")); assert len(fs)==1
        op="control/native" if k=="native" else ("wasmtime/" if v=="wasmtime" else "llvm/")+k
        p=fs[0];assert load(p.with_name("benchmark.json"))["full_id"]==op
        s=load(p.with_name("sample.json"));assert len(s["times"])==len(s["iters"])==24
        assert all(y>0 and x>0 for x,y in zip(s["iters"],s["times"]))
        est=load(p); raw_slope=(est["slope"] or est["mean"])["point_estimate"]
        assert row["slope_ns"]==raw_slope
        if est["slope"]:
            fitted=sum(x*y for x,y in zip(s["iters"],s["times"]))/sum(x*x for x in s["iters"])
            assert math.isclose(fitted,raw_slope,rel_tol=1e-12),(suite,k,v,raw_slope,fitted)
        ns[k][v].append(raw_slope/count); orders[i,k].append(v)
        rows.append(dict(suite=suite,case=k,block=i,arm=v,position=len(orders[i,k]),raw_batch_ns=raw_slope,iterations_per_batch=count,ns_per_op=raw_slope/count,process_cpu_seconds=row["child_cpu_seconds"],process_elapsed_seconds=row["elapsed"],system_load_1=row["load"][0]))
    assert len(rows)==(370 if suite=="entry" else 224)
    for k in des["cases"]:
        arms=ENG[:3] if k=="native" else ENG; num=6 if k=="native" else 8; n=len(arms)
        for i in range(1,9): assert orders[i,k]==des["positions"][k][i-1]
        for pos in range(n):
            assert Counter(orders[i,k][pos] for i in range(1,num+1))==dict.fromkeys(arms,num//n)
        carr=Counter((a,b) for i in range(1,num+1) for a,b in zip(orders[i,k],orders[i,k][1:]))
        assert len(carr)==n*(n-1) and set(carr.values())=={num//n}
        for v in arms: assert median(ns[k][v])==ag[k]["median_ns"][v]/count
        for a,b in [("imports_only","pr"),("scalar_result","pr"),("scalar_result","imports_only")]:
            ratios=[x/y for x,y in zip(ns[k][a],ns[k][b])]
            calc=ag[k]["paired"][f"{a}_over_{b}"]; assert calc["ratios"]==ratios and calc["median"]==median(ratios)
            assert sorted(ratios)[-2 if num==8 else -1]==calc["upper_95"]
            statrows.append(dict(suite=suite,case=k,candidate=a,baseline=b,paired_ratio=median(ratios),upper95_ratio=calc["upper_95"],faster_blocks=sum(x<1 for x in ratios),blocks=num))
    return rows,statrows,ns
def main():
    a=argparse.ArgumentParser();a.add_argument("root",type=Path);a.add_argument("output",type=Path);a.add_argument("--suite",choices=["entry","imports"]); opt=a.parse_args()
    p=opt.root.resolve();dest=opt.output;dest.mkdir(exist_ok=True,parents=True); raw=p/"raw";h=p/"harness"
    rows=[];stats=[];allocs=[];heads=["# Apple M5 Max call benchmarks","",
        f"The Apple M5 Max ran the same Rust fixtures as the [AMD benchmark]({GH}/actions/runs/44197172290). Both suites used Wasmer LLVM 23.1.5 and Wasmtime 50.0.1 Cranelift through their native Rust APIs. Rust 1.99.1 compiled Mach-O arm64 release binaries. The operating system scheduled the processes on this 18-core Mac. The local V8 timing and Rust release builds finished before the Rust timings began.","",
        f"The **Base** commit contains the original #7195 implementation. **Imports** adds the published import optimizations. **Scalar** adds the one-result dynamic export prototype to Imports. [Base]({GH}/commit/{BASE}) · [Imports]({GH}/commit/{IM}) · [Scalar]({GH}/commit/{SC}) · [Frozen Rust fixtures and lock]({GH}/tree/{H}/benches/x64_calls)","",
        "Each table reports median wall-clock nanoseconds per operation. Parentheses show millions of operations per second. Each of eight blocks measures all four arms in a position- and carryover-balanced order. The separate native control runs all six orders of the three Wasmer executables. Each estimate uses 24 Criterion samples after 0.2 s warm-up and a 0.4 s measurement target. Each revision uses a fresh Wasmer API, VM and LLVM build in its own target directory. The Wasmtime column always uses the baseline binary.",""]
    for suite in ([opt.suite] if opt.suite else CASES):
        rr,ss,ns=verify(raw,h,suite);rows+=rr;stats+=ss
        heads+=[f"## {'Rust host → Wasm' if suite=='entry' else 'Wasm guest → Rust host'}","","A row measures one complete outer call using a cached handle. Suspended calls return Pending once and resume. Dynamic Wasmer exports return owned values. Wasmtime dynamic exports use caller-provided result storage." if suite=="entry" else "Each typed outer entry runs 4,096 dependent guest iterations. Every import iteration calls the host once. A pending import suspends and resumes once per iteration. The guest-only control keeps the same arithmetic and byte load in the guest. The raw slope is divided by 4,096.","","| Case | Base | Imports | Scalar | Wasmtime |","| --- | ---: | ---: | ---: | ---: |"]
        for variant in ENG:
            records=defaultdict(list)
            arm=variant if variant!="wasmtime" else "pr"
            for r in csv.DictReader((raw/suite/f"allocations-{arm}.csv").open()):
                eng,k=r["case"].split("/")
                if eng!=("wasmtime" if variant=="wasmtime" else "llvm") and not (eng=="control" and variant!="wasmtime"):continue
                denominator=int(r["outer_iterations"])*(4096 if suite=="imports" else 1)
                n=sum(int(r[f]) for f in ("alloc","alloc_zeroed","realloc"))/denominator
                records[k].append((n,int(r["bytes_requested"])/denominator))
            for k,obs in records.items():
                assert len(obs)==3
                med=[median(x) for x in zip(*obs)]
                allocs.append(dict(suite=suite,case=k,arm=variant,allocations_per_op=med[0],bytes_requested_per_op=med[1]))
        for k,title in CASES[suite]:
            vals=ns[k]; heads.append("| "+title+" | "+" | ".join(f"{median(vals[v]):.2f} ({1000/median(vals[v]):.1f})" if v in vals else "—" for v in ENG)+" |")
        heads+=[""]
    if not opt.suite:
        def t(suite,case,arm):
            return median(r["ns_per_op"] for r in rows if (r["suite"],r["case"],r["arm"])==(suite,case,arm))
        dy0,dy1=(t("entry","dynamic",x) for x in ("imports_only","scalar_result"))
        guest0,guest1=(t("imports","import_typed_ready",x) for x in ("pr","imports_only"))
        wt=t("entry","typed","wasmtime")
        heads[2:2]=[f"The published import changes raised ready typed guest-to-host throughput from {1000/guest0:.1f} to {1000/guest1:.1f} million/s on this Mac. The scalar-result prototype moved dynamic host-to-guest calls from {dy0:.2f} to {dy1:.2f} ns. Wasmtime’s typed export took {wt:.2f} ns.", ""]
    csvwrite(dest/"rust-blocks.csv",rows);csvwrite(dest/"rust-paired.csv",stats);csvwrite(dest/"rust-allocations.csv",allocs)
    heads+=["## Paired changes","","Each cell shows the median within-block latency change followed by the one-sided 95% upper bound. Negative numbers mean faster calls. The CSV contains all 57 Rust comparisons when both suites are present.","","| Case | Imports vs Base | Scalar vs Imports |","| --- | ---: | ---: |"]
    for suite in ([opt.suite] if opt.suite else CASES):
        for k,title in CASES[suite]:
            if k in ("native","guest_loop"):continue
            out=[]
            for va,vb in [("imports_only","pr"),("scalar_result","imports_only")]:
                st=next(x for x in stats if (x["suite"],x["case"],x["candidate"],x["baseline"])==(suite,k,va,vb))
                out.append(f"{pct(st['paired_ratio'])} / {pct(st['upper95_ratio'])} ({st['faster_blocks']}/{st['blocks']} faster)")
            heads+=["| "+("Export" if suite=="entry" else "Import")+" · "+title+" | "+" | ".join(out)+" |"]
    heads+=["",f"The Rust verification recalculated {len(rows)} Criterion point estimates from {len(rows)*24:,} samples, checked per-case call IDs and fixture hashes, verified every crossover position and adjacent pair, and recomputed all {len(stats)} paired comparisons. The raw block table includes batch size, unnormalized slope and ns per operation. [Rust block estimates](rust-blocks.csv) · [Paired results](rust-paired.csv)"]
    clock=[r["process_cpu_seconds"]/r["process_elapsed_seconds"] for r in rows]
    loads=[r["system_load_1"] for r in rows]
    watch=load(raw/"load-watch.json") if (raw/"load-watch.json").is_file() else []; w=watch[-1] if watch else None
    if w is not None and (p/"discarded-pilot/schedule.jsonl").exists():
        pilot_count=len((p/"discarded-pilot/schedule.jsonl").read_text().splitlines())
        heads+=["", f"A superseded {pilot_count}-estimate pilot overlapped a compiler using 971% aggregate CPU. The primary run restarted from block one after a bounded check for compiler activity (under 100% aggregate over three checks, five seconds apart, or two minutes elapsed). All eight primary blocks remain in the results. Criterion analysis used one Rayon worker.", f"At restart, tracked compilers were using {w['compiler_percent']:.1f}% CPU after {w['seconds']:.1f} seconds of observation."]
    heads+=["", f"Across the {len(rows)} retained processes, median one-minute system load was {median(loads):.1f} (range {min(loads):.1f}–{max(loads):.1f}). Median whole-process CPU time was {median(clock)*100:.1f}% of elapsed time (tenth percentile {statistics.quantiles(clock,n=10)[0]*100:.1f}%). The process diagnostic sums all threads and includes calibration, warm-up and analysis, so it can exceed 100%. Per-call Rust results use elapsed time. [Allocation counts, requests and bytes per operation](rust-allocations.csv)"]
    for suite in ([opt.suite] if opt.suite else CASES):
        chosen=[r for r in rows if r["suite"]==suite];ls=[r["system_load_1"] for r in chosen]
        shares=[r["process_cpu_seconds"]/r["process_elapsed_seconds"] for r in chosen]
        heads+=["",f"The {suite} suite had median system load {median(ls):.1f} and median whole-process CPU/elapsed {100*median(shares):.1f}% (10th–90th percentile {100*statistics.quantiles(shares,n=10)[0]:.1f}–{100*statistics.quantiles(shares,n=10)[-1]:.1f}%)."]
    (dest/"rust-report.md").write_text("\n".join(heads)+"\n")
    print("Verified:",len(rows),"slopes;",len(rows)*24,"samples;",len(stats),"paired effects.")
if __name__=="__main__":main()
