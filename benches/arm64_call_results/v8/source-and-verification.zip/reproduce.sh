#!/bin/bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
out="${1:?supply a results directory}"
mkdir -p "$out"/{entry,jspi,imports}
out=$(cd "$out" && pwd)
test "$(node -p process.arch)" = arm64
test "$(node -p process.version)" = v26.0.0
export STUDY_CPU_CLOCK="$out/thread_cpu.node"
bash "$here/source/clock/build.sh" "$STUDY_CPU_CLOCK"
node "$here/source/clock/preflight.js" > "$out/clock.json"
python3 "$here/source/entry/run_entry.py" "$out/entry"
node --no-maglev --no-turbo-inline-js-wasm-calls "$here/source/jspi/jspi.js" > "$out/jspi/results.json"
python3 "$here/source/imports/run.py" "$out/imports"
