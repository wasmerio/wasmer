from pathlib import Path
import os,subprocess
d=Path(__file__).resolve().parent
s=d.parent/'source'
node=os.environ.get('NODE26','node')
env=dict(os.environ,STUDY_CPU_CLOCK=str(d.parent/'thread_cpu.node'),STUDY_MIN_CPU_NS='1000')
common=['--allow-natives-syntax','--no-maglev','--no-turbolev','--no-liftoff','--no-wasm-inlining','--no-wasm-lazy-compilation','--no-concurrent-recompilation']
for mode,wrapper in [('separate',False),('wrapper',True)]:
 for case,driver,index in [('direct-add','addLoop','5'),('nested2-id','identityLoop','11')]:
  flags=[*common, ('--' if wrapper else '--no-')+'turbo-inline-js-wasm-calls','--no-turboshaft-wasm-in-js-inlining','--trace-turbo-inlining','--print-opt-code','--print-opt-code-filter='+driver,'--print-wasm-code','--print-wasm-code-function-index='+index]
  r=subprocess.run([node,*flags,str(s/'entry'/'entry.js'),case,'8000'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
  (d/(mode+'-'+case+'.log')).write_text(r.stdout)
  r.check_returncode()
with (d/'jspi-trace.log').open('w') as f:
 subprocess.run([node,'--no-maglev','--no-turbo-inline-js-wasm-calls','--require',str(d/'capture-module.js'),str(s/'jspi'/'jspi.js'),'verify'],env=env,stdout=f,stderr=f,check=True)
