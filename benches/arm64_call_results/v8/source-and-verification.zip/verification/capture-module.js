const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ctor = WebAssembly.Module;
let captured = 0;
WebAssembly.Module = new Proxy(ctor, { construct(target, args) {
  const bytes = Buffer.from(args[0]);
  const hash = crypto.createHash('sha256').update(bytes).digest('hex');
  fs.writeFileSync(path.join(__dirname, 'jspi-module.wasm'), bytes);
  fs.appendFileSync(path.join(__dirname, 'jspi-verify.log'), JSON.stringify({length:bytes.length,sha256:hash})+'\n');
  captured++;
  return Reflect.construct(target,args);
}});
process.on('exit', code => { if (!captured || code) process.exitCode = 1; });
