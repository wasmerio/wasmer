# uutils Coreutils Documentation

uutils is an attempt at writing universal (as in cross-platform) CLI utilities in Rust. It is available for Linux, Windows, Mac and other platforms.

The API reference for uucore, the library of functions shared between various utils, is hosted at docs.rs.

uutils is licensed under the MIT License.

## Multi-call binary

uutils includes a multi-call binary from which the utils can be invoked. This reduces the binary size of the binary and can be useful for portability.

The first argument of the multi-call binary is the util to run, after which the regular arguments to the util can be passed.

```
coreutils [util] [util options]
The --help flag will print a list of available utils.

Example
coreutils ls -l
```